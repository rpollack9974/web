Code written by John Bergdall and Robert Pollack.

There is no installation necessary for the two files of commands koike.sage and mu_lambda_slopes.sage.

koike.sage is the main file. The main command is Up_charseries_coeffs which will output the characteristic series of Up = 1 + a1(T)X + a2(T)X^2 + … acting in a tame level with specified parameter(s). The whole command takes as input:

Up_charseries_coeffs(N,p,max_i,r,cusp=true/false,gamma,M1,M2,verbose)

N is the tame level. p is the prime. max_i is the number of coefficients to compute (so max_i = 5 will compute the coefficients a0,a1,a2,a3 and a4). The value r is telling which component to work on in the p-adic weight space, i.e. it is specifying a congruence class of integers k = r mod p-1. The rest of the variables have defaults that you are free to use. The cusp variable is a true/false flag that either computes the characteristic series for cuspidal overconvergent p-adic forms (if true) or all modular overconvergent p-adic forms (if false). gamma is a specified topological generator of the maximal pro-cyclic subgroup of Z_p^x. It will default to gamma = 1+p if p is odd, and gamma = 5 if p = 2. M1 is measuring the *p-adic* accuracy of the coefficients (it is precisely saying how far to compute the p-adic logarithms necessary to turn Iwasawa algebra elements into the variable T). M2 is measuring the T-adic accuracy of each coefficient, i.e. how many terms in each ai(T) to compute. Finally, the verbose flag is true/false depending on if you want a play-by-play output of what the script is doing.

The file mu_lambda_slopes.sage is a file containing a handful of small scripts that packages a lot of the data we mined into one or two commands. The inputs are exactly the same as the previous paragraph so we leave it to you to figure out through the examples (and the comments in the code).

If you are just interested in the characteristic series of U_2 in tame level 1 then we have included that as a sage object. You can load it by writing charU2 = load(‘charU2.sobj’). But a warning: the 2-adic accuracy was very high (there are 20 coefficients) and so it might seem unwieldy. 

Below are examples of how to use the code. These are the commands that generated the examples in the paper ``Arithmetic of Fredholm series for p-adic modular forms” (2015).


## Example 4.3

sage: a23 = Up_charseries_coeffs(1,23,5,6,cusp=1,gamma=24,M1=20,M2=15,verbose=true)

sage: [a23[1][j] for j in range(2)]
[18*23 + 11*23^2 + 9*23^3 + 4*23^4 + 20*23^5 + 9*23^6 + 2*23^7 + 19*23^8 + 21*23^9 + 6*23^10 + 18*23^11 + 21*23^12 + 7*23^13 + 21*23^14 + 21*23^15 + 3*23^16 + 14*23^17 + 3*23^18 + 22*23^19 + O(23^20),
 20 + 9*23 + 16*23^2 + 8*23^3 + 9*23^4 + 2*23^5 + 22*23^6 + 14*23^8 + 8*23^9 + 17*23^10 + 7*23^11 + 18*23^13 + 23^14 + 10*23^15 + 20*23^16 + 13*23^17 + 22*23^18 + 14*23^19 + O(23^20)]
 
 sage: [a23[2][j] for j in range(3)]
[11*23^2 + 12*23^3 + 5*23^5 + 8*23^6 + 15*23^7 + 6*23^8 + 15*23^9 + 18*23^10 + 16*23^11 + 22*23^12 + 4*23^13 + 21*23^14 + 4*23^15 + 5*23^16 + 4*23^17 + 15*23^18 + O(23^20),
 4*23 + 8*23^2 + 12*23^3 + 12*23^4 + 10*23^5 + 12*23^6 + 14*23^7 + 3*23^8 + 9*23^9 + 8*23^10 + 8*23^11 + 12*23^12 + 10*23^13 + 16*23^14 + 21*23^15 + 23^16 + 9*23^17 + 19*23^18 + 22*23^19 + O(23^20),
 15 + 2*23 + 14*23^2 + 19*23^3 + 22*23^5 + 9*23^6 + 9*23^7 + 7*23^8 + 12*23^10 + 18*23^11 + 21*23^12 + 5*23^13 + 23^14 + 12*23^15 + 9*23^16 + 6*23^17 + 4*23^18 + 13*23^19 + O(23^20)]
 
sage: [a23[3][j] for j in range(6)]
[4*23^4 + 7*23^6 + 12*23^7 + 7*23^8 + 4*23^9 + 9*23^10 + 15*23^11 + 12*23^13 + 22*23^14 + 18*23^15 + 9*23^16 + 6*23^17 + 10*23^18 + 4*23^19 + O(23^20),
 4*23^3 + 10*23^4 + 8*23^5 + 5*23^6 + 22*23^7 + 13*23^9 + 8*23^10 + 3*23^11 + 9*23^12 + 5*23^13 + 7*23^14 + 11*23^15 + 4*23^16 + 20*23^17 + 4*23^18 + 14*23^19 + O(23^20),
 6*23^2 + 14*23^3 + 8*23^4 + 14*23^5 + 23^6 + 14*23^7 + 23^8 + 14*23^9 + 5*23^10 + 9*23^11 + 2*23^12 + 9*23^13 + 15*23^14 + 14*23^15 + 3*23^16 + 11*23^17 + 23^18 + 2*23^19 + O(23^20),
 23 + 20*23^2 + 2*23^3 + 10*23^4 + 16*23^5 + 3*23^6 + 8*23^7 + 8*23^8 + 15*23^9 + 20*23^10 + 20*23^11 + 8*23^12 + 6*23^13 + 21*23^14 + 16*23^15 + 11*23^18 + 7*23^19 + O(23^20),
 13*23 + 10*23^2 + 18*23^3 + 6*23^4 + 6*23^5 + 4*23^6 + 9*23^7 + 11*23^8 + 19*23^9 + 20*23^10 + 7*23^11 + 17*23^12 + 5*23^13 + 20*23^14 + 23^15 + 3*23^16 + 5*23^17 + 2*23^18 + 7*23^19 + O(23^20),
 3 + 4*23 + 2*23^2 + 9*23^3 + 17*23^4 + 5*23^5 + 13*23^6 + 23^7 + 19*23^8 + 22*23^9 + 7*23^10 + 4*23^11 + 7*23^12 + 22*23^13 + 6*23^14 + 4*23^15 + 18*23^16 + 21*23^17 + 21*23^18 + 19*23^19 + O(23^20)]
 
sage: [a23[4][j] for j in range(7)]
[21*23^6 + 20*23^7 + 14*23^8 + 7*23^9 + 5*23^10 + 6*23^11 + 2*23^12 + 21*23^13 + 9*23^14 + 2*23^15 + 17*23^16 + 6*23^17 + 4*23^18 + O(23^20),
 16*23^5 + 7*23^6 + 7*23^7 + 21*23^8 + 7*23^9 + 22*23^10 + 20*23^11 + 17*23^12 + 8*23^13 + 15*23^14 + 19*23^15 + 5*23^16 + 5*23^17 + 4*23^18 + 11*23^19 + O(23^20),
 11*23^4 + 13*23^5 + 4*23^6 + 19*23^7 + 21*23^8 + 2*23^9 + 10*23^10 + 22*23^11 + 22*23^12 + 19*23^13 + 14*23^14 + 15*23^15 + 19*23^16 + 13*23^17 + 4*23^18 + 13*23^19 + O(23^20),
 3*23^3 + 20*23^4 + 15*23^5 + 8*23^6 + 18*23^7 + 20*23^8 + 13*23^9 + 2*23^10 + 13*23^11 + 8*23^12 + 6*23^13 + 15*23^14 + 18*23^15 + 11*23^16 + 23^17 + 5*23^18 + 22*23^19 + O(23^20),
 2*23^2 + 17*23^3 + 23^4 + 16*23^5 + 5*23^6 + 5*23^7 + 21*23^8 + 20*23^9 + 11*23^10 + 15*23^11 + 19*23^12 + 10*23^13 + 9*23^14 + 12*23^15 + 13*23^16 + 9*23^17 + 2*23^18 + 18*23^19 + O(23^20),
 10*23 + 23^2 + 9*23^3 + 2*23^4 + 16*23^5 + 16*23^6 + 5*23^7 + 14*23^8 + 15*23^9 + 4*23^10 + 12*23^11 + 13*23^12 + 5*23^13 + 19*23^14 + 4*23^15 + 7*23^16 + 13*23^17 + 23^18 + 15*23^19 + O(23^20),
 21 + 17*23 + 12*23^2 + 23^3 + 8*23^4 + 10*23^5 + 5*23^6 + 22*23^7 + 18*23^8 + 20*23^9 + 12*23^10 + 6*23^11 + 22*23^12 + 2*23^13 + 17*23^14 + 21*23^15 + 19*23^16 + 13*23^17 + 19*23^18 + 14*23^19 + O(23^20)]


## Example 4.4
sage: a5_3 = Up_charseries_coeffs(3,5,2,0,cusp=1,gamma=6,M1=10,M2=20,verbose=true)

sage: [a5_3[1][j] for j in range(6)]
[2*5 + 5^2 + 4*5^4 + 2*5^5 + 3*5^6 + 2*5^7 + 2*5^8 + 5^9 + O(5^10),
 5 + 2*5^2 + 2*5^3 + 3*5^5 + 4*5^6 + 2*5^7 + 2*5^8 + 5^9 + 2*5^10 + O(5^11),
 2*5 + 2*5^2 + 2*5^3 + 5^5 + 2*5^6 + 3*5^7 + 4*5^8 + 3*5^9 + 5^10 + O(5^11),
 2*5 + 5^2 + 2*5^4 + 3*5^5 + 2*5^6 + 5^7 + 5^8 + 4*5^9 + 5^10 + O(5^11),
 5 + 5^2 + 3*5^3 + 4*5^4 + 4*5^6 + 2*5^8 + 5^10 + O(5^11),
 1 + 2*5 + 2*5^2 + 5^3 + 2*5^4 + 3*5^5 + 3*5^6 + 4*5^8 + 3*5^9 + O(5^10)]
 
 
## Table 1
sage: mu_lambda_slopes_data(3,5,9,0,cusp=1,gamma=6,M1=100,M2=50,verbose=true)
cusp
 p=5, N=3, j_max=9, r=0

Getting the trace of powers of U_5 at tame + cusp level N = 3

		 Computing trace(U_5^1) in cuspidal level N = 3 on component r = 0
		 Computing trace(U_5^2) in cuspidal level N = 3 on component r = 0
		 Computing trace(U_5^3) in cuspidal level N = 3 on component r = 0
		 Computing trace(U_5^4) in cuspidal level N = 3 on component r = 0
		 Computing trace(U_5^5) in cuspidal level N = 3 on component r = 0
		 Computing trace(U_5^6) in cuspidal level N = 3 on component r = 0
		 Computing trace(U_5^7) in cuspidal level N = 3 on component r = 0
		 Computing trace(U_5^8) in cuspidal level N = 3 on component r = 0

Coefficient data:

0:
	 mu = +Infinity
	 lm = 0
	 slopes:[]
1:
	 mu = 0
	 lm = 5
	 slopes:[1/5, 1/5, 1/5, 1/5, 1/5]
2:
	 mu = 0
	 lm = 2
	 slopes:[1, 1]
3:
	 mu = 0
	 lm = 3
	 slopes:[2, 1, 1]
4:
	 mu = 0
	 lm = 4
	 slopes:[1, 1, 1, 1]
5:
	 mu = 0
	 lm = 7
	 slopes:[1, 1, 1, 1, 1, 1, 1]
6:
	 mu = 0
	 lm = 10
	 slopes:[2, 1, 1, 1, 1, 1, 1, 1, 1, 1]
7:
	 mu = 0
	 lm = 14
	 slopes:[2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1/2, 1/2]
8:
	 mu = 0
	 lm = 16
	 slopes:[2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]


## Example 4.14
sage: a197_3 = Up_charseries_coeffs(197,3,3,0,cusp=1,M1=50,M2=10,verbose=true)
sage: a197_3[0]
1
sage: a197_3[1]
(2 + O(3^50))
sage: a197_3[2]
(3 + O(3^50))

## Table 2
sage: mu_lambda_slopes_data(7,2,10,0,cusp=1,gamma=5,M1=100,M2=50,verbose=true)
cusp
 p=2, N=7, j_max=10, r=0

Getting the trace of powers of U_2 at tame + cusp level N = 7

		 Computing trace(U_2^1) in cuspidal level N = 7 on component r = 0
		 Computing trace(U_2^2) in cuspidal level N = 7 on component r = 0
		 Computing trace(U_2^3) in cuspidal level N = 7 on component r = 0
		 Computing trace(U_2^4) in cuspidal level N = 7 on component r = 0
		 Computing trace(U_2^5) in cuspidal level N = 7 on component r = 0
		 Computing trace(U_2^6) in cuspidal level N = 7 on component r = 0
		 Computing trace(U_2^7) in cuspidal level N = 7 on component r = 0
		 Computing trace(U_2^8) in cuspidal level N = 7 on component r = 0
		 Computing trace(U_2^9) in cuspidal level N = 7 on component r = 0

Coefficient data:

0:
	 mu = +Infinity
	 lm = 0
	 slopes:[]
1:
	 mu = 0
	 lm = 0
	 slopes:[]
2:
	 mu = 0
	 lm = 2
	 slopes:[1, 1]
3:
	 mu = 0
	 lm = 2
	 slopes:[1, 1]
4:
	 mu = 0
	 lm = 2
	 slopes:[4, 4]
5:
	 mu = 0
	 lm = 2
	 slopes:[4, 4]
6:
	 mu = 0
	 lm = 6
	 slopes:[4, 4, 3, 2, 1/2, 1/2]
7:
	 mu = 0
	 lm = 6
	 slopes:[7/2, 7/2, 3, 3, 1/2, 1/2]
8:
	 mu = 0
	 lm = 6
	 slopes:[4, 7/2, 7/2, 3, 3, 3]
9:
	 mu = 0
	 lm = 6
	 slopes:[4, 4, 3, 3, 3, 3]

## table 4
sage: mu_lambda_slopes_data(1,3,7,0,cusp=1,gamma=4,M1=100,M2=70,verbose=true)
cusp
 p=3, N=1, j_max=7, r=0

Getting the trace of powers of U_3 at tame + cusp level N = 1

		 Computing trace(U_3^1) in cuspidal level N = 1 on component r = 0
		 Computing trace(U_3^2) in cuspidal level N = 1 on component r = 0
		 Computing trace(U_3^3) in cuspidal level N = 1 on component r = 0
		 Computing trace(U_3^4) in cuspidal level N = 1 on component r = 0
		 Computing trace(U_3^5) in cuspidal level N = 1 on component r = 0
		 Computing trace(U_3^6) in cuspidal level N = 1 on component r = 0

Coefficient data:

0:
	 mu = +Infinity
	 lm = 0
	 slopes:[]
1:
	 mu = 0
	 lm = 2
	 slopes:[1, 1]
2:
	 mu = 0
	 lm = 6
	 slopes:[3, 1, 1, 1, 1, 1]
3:
	 mu = 0
	 lm = 12
	 slopes:[3, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1]
4:
	 mu = 0
	 lm = 20
	 slopes:[3, 2, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
5:
	 mu = 0
	 lm = 30
	 slopes:[4, 3, 3, 2, 2, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
6:
	 mu = 0
	 lm = 42
	 slopes:[4, 4, 3, 3, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
	 


## Table 5

sage: mu_lambda_slopes_data(3,2,8,0,cusp=1,gamma=5,M1=100,M2=70,verbose=true)
cusp
 p=2, N=3, j_max=8, r=0

Getting the trace of powers of U_2 at tame + cusp level N = 3

		 Computing trace(U_2^1) in cuspidal level N = 3 on component r = 0
		 Computing trace(U_2^2) in cuspidal level N = 3 on component r = 0
		 Computing trace(U_2^3) in cuspidal level N = 3 on component r = 0
		 Computing trace(U_2^4) in cuspidal level N = 3 on component r = 0
		 Computing trace(U_2^5) in cuspidal level N = 3 on component r = 0
		 Computing trace(U_2^6) in cuspidal level N = 3 on component r = 0
		 Computing trace(U_2^7) in cuspidal level N = 3 on component r = 0

Coefficient data:

0:
	 mu = +Infinity
	 lm = 0
	 slopes:[]
1:
	 mu = 1
	 lm = 0
	 slopes:[]
2:
	 mu = 0
	 lm = 1
	 slopes:[4]
3:
	 mu = 1
	 lm = 2
	 slopes:[3, 3]
4:
	 mu = 0
	 lm = 3
	 slopes:[4, 3, 3]
5:
	 mu = 1
	 lm = 4
	 slopes:[8, 4, 3, 3]
6:
	 mu = 0
	 lm = 6
	 slopes:[6, 5, 4, 3, 3, 3]
7:
	 mu = 1
	 lm = 8
	 slopes:[6, 4, 4, 4, 3, 3, 3, 3]

## Table 6
sage: mu_lambda_slopes_data(3,5,9,0,cusp=1,gamma=6,M1=100,M2=70,verbose=true)
cusp
 p=5, N=3, j_max=9, r=0

Getting the trace of powers of U_5 at tame + cusp level N = 3

		 Computing trace(U_5^1) in cuspidal level N = 3 on component r = 0
		 Computing trace(U_5^2) in cuspidal level N = 3 on component r = 0
		 Computing trace(U_5^3) in cuspidal level N = 3 on component r = 0
		 Computing trace(U_5^4) in cuspidal level N = 3 on component r = 0
		 Computing trace(U_5^5) in cuspidal level N = 3 on component r = 0
		 Computing trace(U_5^6) in cuspidal level N = 3 on component r = 0
		 Computing trace(U_5^7) in cuspidal level N = 3 on component r = 0
		 Computing trace(U_5^8) in cuspidal level N = 3 on component r = 0

Coefficient data:

0:
	 mu = +Infinity
	 lm = 0
	 slopes:[]
1:
	 mu = 0
	 lm = 5
	 slopes:[1/5, 1/5, 1/5, 1/5, 1/5]
2:
	 mu = 0
	 lm = 2
	 slopes:[1, 1]
3:
	 mu = 0
	 lm = 3
	 slopes:[2, 1, 1]
4:
	 mu = 0
	 lm = 4
	 slopes:[1, 1, 1, 1]
5:
	 mu = 0
	 lm = 7
	 slopes:[1, 1, 1, 1, 1, 1, 1]
6:
	 mu = 0
	 lm = 10
	 slopes:[2, 1, 1, 1, 1, 1, 1, 1, 1, 1]
7:
	 mu = 0
	 lm = 14
	 slopes:[2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1/2, 1/2]
8:
	 mu = 0
	 lm = 16
	 slopes:[2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]

