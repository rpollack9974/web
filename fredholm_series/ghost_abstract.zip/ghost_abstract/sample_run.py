load("ghost_object.sage")

print "We define a mod p representation rb"

rb = rbdata(17,12,false,[1])

print "This rhobar has p=17, has Serre weight 12, is non-split globally, and has multiplicity 1 in weight 12."
print "For instance, this rhobar could be arising from Delta with p=17."

print "Now we define the corresponding ghost series"

g = ghost(terms=100,rbdata=rb,twist=0)

print g

print "Now we compute the slopes in weight k"

k=492
print g.slopes(k)

print "Now we compute the classical T_p-slopes in weight k"

print g.slopes(k)[0:S(k,0,rb)]

print "Now we compute the classical U_p-slopes in weight k"

print g.slopes(k)[0:Sp(k,0,rb)]

print "We can also form the ghost series attached to twists of this rhobar.  Here is the ghost series for rhobar otimes omega."

g = ghost(terms=100,rbdata=rb,twist=1)

print g

print "And here are the slopes for this twisted ghost series in weight 494"

print g.slopes(494)